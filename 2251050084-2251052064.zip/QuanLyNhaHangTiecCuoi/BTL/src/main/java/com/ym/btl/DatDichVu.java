/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ym.btl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author ADMIN
 */
public class DatDichVu {
    List<DichVu> ddv=new ArrayList<>();

public List<DichVu> getDsDichVu() {
        return ddv;
    }

    void themDichVu(DichVu...a){
        this.ddv.addAll(Arrays.asList(a));
   }
    public void hienThi(){
        for(DichVu dichVu:ddv){
            dichVu.hienThi();
        }
    }
        

}

