/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ym.btl;

/**
 *
 * @author ADMIN
 */
public abstract class DichVu {
    protected static int dem;
    protected String maDV;
    private String tenDV;
    private double giaDV;
    public DichVu( String tenDV, double giaDV) {
    
        this.tenDV = tenDV;
        this.giaDV = giaDV;
    }
    public abstract void hienThi();
    
    /**
     * @return the maDV
     */
    public String getMaDV() {
        return maDV;
    }

    /**
     * @param maDV the maDV to set
     */
    public void setMaDV(String maDV) {
        this.maDV = maDV;
    }

    /**
     * @return the tenDV
     */
    public String getTenDV() {
        return tenDV;
    }

    /**
     * @param tenDV the tenDV to set
     */
    public void setTenDV(String tenDV) {
        this.tenDV = tenDV;
    }

    /**
     * @return the giaDV
     */
    public double getGiaDV() {
        return giaDV;
    }

    /**
     * @param giaDV the giaDV to set
     */
    public void setGiaDV(double giaDV) {
        this.giaDV = giaDV;
    }
    public void setThoiGianThue(int thoiGianThue){
        
    }
    public void setTenCaSi(String tenCaSi){}
    public int setSoLuongBH(int soLuongBH){
        return soLuongBH ;
    }
    
}
   

