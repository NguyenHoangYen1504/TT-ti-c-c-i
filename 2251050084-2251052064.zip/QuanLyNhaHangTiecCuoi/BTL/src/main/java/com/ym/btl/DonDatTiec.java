/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ym.btl;

/**
 *
 * @author Admin
 */
public class DonDatTiec {

    private static int dem;
    private String tenBuaTiec;
    private int maDon=++dem;
    private int ngay, thang, nam;
    private GiaThueSanh giaThueSanh;
    private QuanLySanhCuoi qlsc;
            //=new QuanLySanhCuoi();
    private Menu menu;
    private DatDichVu datDichVu;
    private SanhCuoi sanhCuoi;
   private String maSC;
   

    public DonDatTiec() {

    }
   
    
    
    public DonDatTiec(String tenBuaTiec, String maSC,int ngay, int thang, int nam, GiaThueSanh giaThueSanh,  Menu menu, DatDichVu datDichVu, QuanLySanhCuoi qlsc) {
        this.tenBuaTiec = tenBuaTiec;
        this.ngay = ngay;
        this.thang = thang;
        this.nam = nam;
        this.giaThueSanh = giaThueSanh;
        this.menu = menu;
        this.maSC=maSC;
        this.datDichVu = datDichVu;
        //qlsc.timKiemTheoMaSC(maSC, sanhCuoi);
       this.sanhCuoi = qlsc.timKiemTheoMaSC(maSC);
        sanhCuoi.datTiec();
        sanhCuoi.tangSoLanDatThueTheoNam(nam);

    // Kiểm tra xem sảnhCuoi có tồn tại không trước khi gán
    
    }
   
   
    public double tinhTienMenu() {
        double tongTienMenu = 0.0;

        for (ThucPham thucPham : menu.getTp()) {
            tongTienMenu += thucPham.getGiaMon();
        }

        return tongTienMenu;
    }

    public double tinhTienDichVu() {
        double tongTienDichVu = 0.0;
        for (DichVu dichVu : getDatDichVu().getDsDichVu()) {
               if (dichVu instanceof ThueCaSi a ) {
                tongTienDichVu+=a.getSoLuongBH()*a.getGiaDV();
            }
            if(dichVu instanceof Karaoke a){
                tongTienDichVu+=a.getThoiGianThue()*a.getGiaDV();
            }
             if(dichVu instanceof TrangTri a){
                tongTienDichVu+=a.getGiaDV();
            }
                   
       }
        return tongTienDichVu;
    }

    public GiaThueSanh tinhTienThueSanh() {
        // Điều này tùy thuộc vào cách bạn quy định giá thuê sảnh trong lớp SanhCuoi
        return this.giaThueSanh;
    }

    public double tinhTongTien() {
        double tongTien = 0.0;

        // Tính tổng tiền từ các món ăn và thức uống trong Menu
        tongTien += tinhTienMenu()*this.sanhCuoi.getSucChua();
        // Tính tổng tiền từ các dịch vụ
        tongTien += tinhTienDichVu();

        // Tính tổng tiền từ việc thuê sảnh cưới
        tongTien +=layGiaThueSanh(giaThueSanh);

        return tongTien;

    }

    

    public double layGiaThueSanh(GiaThueSanh giaThueSanh) {
        // Sử dụng switch-case để lấy giá trị tương ứng từ enum
        switch (giaThueSanh) {
            case SANG_THUONG:
                return GiaThueSanh.SANG_THUONG.layGIaThue();
            case TRUA_THUONG:
                return GiaThueSanh.TRUA_THUONG.layGIaThue();
            case CHIEU_THUONG:
                return GiaThueSanh.CHIEU_THUONG.layGIaThue();
            case SANG_T7CN:
                return GiaThueSanh.SANG_T7CN.layGIaThue();
            case TRUA_T7CN:
                return GiaThueSanh.TRUA_T7CN.layGIaThue();
            case TOI_T7CN:
                return GiaThueSanh.TOI_T7CN.layGIaThue();

            // Thêm các trường hợp khác tương ứng với các giá trị của enum
            default:
                return 0.0; // Giá trị mặc định hoặc xử lý khác tùy vào logic của bạn
        }
    }
    public void nhap1DDT(){
        System.out.println("\nNhap ten bua tiec:");
         this.tenBuaTiec = CauHinh.SC.nextLine();
        System.out.println("\nSanh thue:");
       String maSanh = CauHinh.SC.nextLine();
       // this.sanhCuoi = qlsc.laySanhCuoiTheoMa(maSanh);
        System.out.println("\nChon thoi diem thue sanh (SANG_THUONG, TRUA_THUONG, CHIEU_THUONG,SANG_T7CN,TRUA_T7CN,TOI_T7CN):");
        String thoiDiem = CauHinh.SC.nextLine().toUpperCase();

        // Chuyển đổi từ String nhập vào thành giá trị enum GiaThueSanh
        GiaThueSanh giaThue = GiaThueSanh.valueOf(thoiDiem);

        // Gán giá trị enum vào giaThueSanh của đối tượng SanhCuoi
       this.giaThueSanh = giaThue;
        System.out.println("\nNgay: ");
         this.ngay = CauHinh.SC.nextInt();
        System.out.println("\nThang: ");
         this.thang = CauHinh.SC.nextInt();
        System.out.println("\nNam: ");
        this.nam = CauHinh.SC.nextInt();
        System.out.println("\nSo ban: ");
        this.sanhCuoi.getSucChua();
        
        
        
    }
   

//    public String getMaSanh() {
//        return maSanh;
//    }

    public SanhCuoi getSanhCuoi() {
        return sanhCuoi;
    }
    
        /**
         * @return the tenBuaTiec
         */
    public String getTenBuaTiec() {
        return tenBuaTiec;
    }

    /**
     * @param tenBuaTiec the tenBuaTiec to set
     */
    public void setTenBuaTiec(String tenBuaTiec) {
        this.tenBuaTiec = tenBuaTiec;
    }

    /**
     * @return the maDon
     */
    public int getMaDon() {
        return maDon;
    }

    /**
     * @param maDon the maDon to set
     */
    public void setMaDon(int maDon) {
        this.maDon = maDon;
    }

    /**
     * @return the ngay
     */
    public int getNgay() {
        return ngay;
    }

    /**
     * * @param ngay the ngay to set
     */
    public void setNgay(int ngay) {
        this.ngay = ngay;
    }

    /**
     * @return the thang
     */
    public int getThang() {
        return thang;
    }

    /**
     * @param thang the thang to set
     */
    public void setThang(int thang) {
        this.thang = thang;
    }

    /**
     * @return the nam
     */
    public int getNam() {
        return nam;
    }

    /**
     * @param nam the nam to set
     */
    public void setNam(int nam) {
        this.nam = nam;
    }

    /**
     * @return the giaThueSanh
     */
    public GiaThueSanh getGiaThueSanh() {
        return giaThueSanh;
    }

    /**
     * @param giaThueSanh the giaThueSanh to set
     */
    public void setGiaThueSanh(GiaThueSanh giaThueSanh) {
        this.giaThueSanh = giaThueSanh;
    }

    @Override
    public String toString() {
        return "\nTen bua tiec: " + this.tenBuaTiec + "\nMa don: " + this.maDon + "\nGia thue sanh: " + this.giaThueSanh.layGIaThue() + "\nNgay: " + this.ngay
                + "\nThang: " + this.thang + "\nNam: " + this.nam+"\nMa Sanh:"+this.getMaSC();
    }

    /**
     * @return the ngayToChuc
     */
    

    /**
     * @return the sanhCuoi
     */
  

    /**
     * @param sanhCuoi the sanhCuoi to set
     */
    public void setSanhCuoi(SanhCuoi sanhCuoi) {
        this.sanhCuoi = sanhCuoi;
    }

    /**
     * @return the menu
     */
    public Menu getMenu() {
        return menu;
    }

    /**
     * @param menu the menu to set
     */
    public void setMenu(Menu menu) {
        this.menu = menu;
    }



    /**
     * @return the qlsc
     */
    public QuanLySanhCuoi getQlsc() {
        return qlsc;
    }

    /**
     * @param qlsc the qlsc to set
     */
    public void setQlsc(QuanLySanhCuoi qlsc) {
        this.qlsc = qlsc;
    }

    /**
     * @return the soBan
     */


    /**
     * @return the maSC
     */
    public String getMaSC() {
        return maSC;
    }

    /**
     * @param maSC the maSC to set
     */
    public void setMaSC(String maSC) {
        this.maSC = maSC;
    }

    /**
     * @return the datDichVu
     */
    public DatDichVu getDatDichVu() {
        return datDichVu;
    }

    /**
     * @param datDichVu the datDichVu to set
     */
    public void setDatDichVu(DatDichVu datDichVu) {
        this.datDichVu = datDichVu;
    }

    /**
     * @return the maSanh
     */
    

    /**
     * @return the soBan
     */
    

}
     
