/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ym.btl;

/**
 *
 * @author Admin
 */
public enum GiaThueSanh {
    
    SANG_THUONG(1000),
    TRUA_THUONG(1500),
    CHIEU_THUONG(2000),
    SANG_T7CN(3000),
    TRUA_T7CN(3500),
    TOI_T7CN(4000);
    
    
    private double giaThue;

    private GiaThueSanh(double giaThue) {
        this.giaThue = giaThue;
    }
     public double layGIaThue(){
      return giaThue;
     }
}
