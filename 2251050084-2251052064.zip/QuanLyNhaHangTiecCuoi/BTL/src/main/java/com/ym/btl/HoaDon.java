/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ym.btl;

/**
 *
 * @author ADMIN
 */
public class HoaDon {

    private DonDatTiec donDatTiec;

    public HoaDon() {

    }

    public HoaDon(DonDatTiec donDatTiec) {
        this.donDatTiec = donDatTiec;
    }

    public void xuatHoaDon() {
        System.out.println("\nHoa don:");
        System.out.printf("\nTen bua tiec: %s", this.getDonDatTiec().getTenBuaTiec());

        System.out.println("\nSanh :" + this.getDonDatTiec().getSanhCuoi().getMaSanh() + "-> " + this.getDonDatTiec().getGiaThueSanh().layGIaThue());
        System.out.printf("==========Menu===========\n");

        for (ThucPham thucPham : this.getDonDatTiec().getMenu().getTp()) {
            if (thucPham instanceof ThucAn thucAn) {
                System.out.println(thucAn.getTenMon() + ": " + thucAn.getGiaMon());
            }

            if (thucPham instanceof ThucUong thucUong) {
                System.out.println(thucUong.getTenMon() + ": " + thucUong.getGiaMon());
            }
        }

        System.out.println("==========Dich Vu==========");
        for (DichVu dichVu : this.getDonDatTiec().getDatDichVu().getDsDichVu()) {
            System.out.println(dichVu.getTenDV() + ":" + dichVu.getGiaDV());
        }

        System.out.println("So Ban: " + this.getDonDatTiec().getSanhCuoi().getSucChua());

        System.out.println("Tong cong: " + this.getDonDatTiec().tinhTongTien());
    }

    /**
     * @return the donDatTiec
     */
    public DonDatTiec getDonDatTiec() {
        return donDatTiec;
    }

    /**
     * @param donDatTiec the donDatTiec to set
     */
    public void setDonDatTiec(DonDatTiec donDatTiec) {
        this.donDatTiec = donDatTiec;
    }
}
