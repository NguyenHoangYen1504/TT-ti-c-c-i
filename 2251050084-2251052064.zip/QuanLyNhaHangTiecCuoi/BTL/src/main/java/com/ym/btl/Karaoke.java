/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ym.btl;

/**
 *
 * @author ADMIN
 */
public class Karaoke extends DichVu{
    private int thoiGianThue;
 {
        this.maDV = String.format("DV%03d", ++dem);
    }

    public Karaoke( double giaDV,int thoiGianThue) {
        super("Karaoke", giaDV);
        this.thoiGianThue = thoiGianThue;
    }
    @Override
   public void hienThi(){
        System.out.printf("===\nDich vu:%s\n Ma dich vu:%s\n Gia dich vu:%.1f\n Thoi gian thue:%d%n",
                this.getTenDV(),this.getMaDV(),this.getGiaDV(),this.thoiGianThue);
   }

    /**
     * @return the thoiGianThue
     */
    public int getThoiGianThue() {
        return thoiGianThue;
    }
    public String getMaDV(String maDV) {
        return maDV;
    }

    /**
     * @param thoiGianThue the thoiGianThue to set
     */
    public void setThoiGianThue(int thoiGianThue) {
        this.thoiGianThue = thoiGianThue;
    }
}

