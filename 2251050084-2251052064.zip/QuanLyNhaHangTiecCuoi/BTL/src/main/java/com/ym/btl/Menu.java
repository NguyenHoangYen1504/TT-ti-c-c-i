/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ym.btl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author ADMIN
 */
public class Menu {
 private  List<ThucPham> tp=new ArrayList<>();


   public void hienThi(){
   for (ThucPham thucPham : getTp()) {
       if (thucPham instanceof ThucAn thucAn) {
                thucAn.xuatMonAn() ;
        }
       if (thucPham instanceof ThucUong thucuong) {
                thucuong.xuatThucUong(); 
        }
   }
   }
//   public void hienThiTienMN(){
//       System.out.printf("\nTong tien menu la:%.1f", tienMenu());
//   }

   public void themVaoMenu(ThucPham...tp) {
       this.getTp().addAll(Arrays.asList(tp));
  }
   public void inDanhSachThucAn() {
        System.out.println("Danh sach thuc an:");
        for (ThucPham thucPham : getTp()) {
            if (thucPham instanceof ThucAn) {
                System.out.println(thucPham.getMaMon() + ": " + thucPham.getTenMon()+": "+thucPham.getGiaMon());
            }
        }
    }
   public void inDanhSachThucUong() {
        
        for (ThucPham thucPham : getTp()) {
            if (thucPham instanceof ThucUong) {
                System.out.println(thucPham.getMaMon() + ": " + thucPham.getTenMon()+": "+thucPham.getGiaMon());
            }
        }
    }
    /**
     * @return the tp
     */
    public List<ThucPham> getTp() {
        return tp;
    }

    /**
     * @param tp the tp to set
     */
    public void setTp(List<ThucPham> tp) {
        this.tp = tp;
    }
    
}


