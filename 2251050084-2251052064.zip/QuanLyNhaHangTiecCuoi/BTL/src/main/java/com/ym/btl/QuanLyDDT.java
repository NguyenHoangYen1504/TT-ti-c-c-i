/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ym.btl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 *
 * @author Admin
 */
public class QuanLyDDT {

    private List<DonDatTiec> dsddt = new ArrayList<>();
    private QuanLySanhCuoi qlsc;

    public QuanLyDDT(QuanLySanhCuoi qlsc) {
        this.qlsc = qlsc;
    }

    public void baoCaoDoanhThuThang(int nam) {

        double[] doanhThuThang = new double[12];

        // Tính doanh thu cho từng đơn đặt tiệc và cập nhật mảng doanh thu
        for (DonDatTiec donDatTiec : dsddt) {
            int namDon = donDatTiec.getNam();
            if (namDon == nam) {
                int thang = donDatTiec.getThang();
                double tongTien = donDatTiec.tinhTongTien();

                // Cộng tổng tiền vào tháng tương ứng trong mảng
                doanhThuThang[thang - 1] += tongTien;
            }
        }

        // Hiển thị báo cáo
        for (int i = 0; i < doanhThuThang.length; i++) {
            System.out.println("Thang " + (i + 1) + ": " + doanhThuThang[i] + " VND");
        }

    }

    public void baoCaoDoanhThuQuy(int nam) {
        System.out.println("Bao cao doanh thu theo quy:");

        double[] doanhThuQuy = new double[4];

        // Tính doanh thu cho từng đơn đặt tiệc và cập nhật mảng doanh thu quý
        for (DonDatTiec donDatTiec : dsddt) {
            int thang = donDatTiec.getThang();
            int namDon = donDatTiec.getNam();
            if (namDon == nam) {
                double tongTien = donDatTiec.tinhTongTien();

                // Xác định quý dựa trên tháng
                int quy = (thang - 1) / 3;

                // Cộng tổng tiền vào quý tương ứng trong mảng
                doanhThuQuy[quy] += tongTien;
            }
        }

        // Hiển thị báo cáo
        for (int i = 0; i < doanhThuQuy.length; i++) {
            System.out.println("Quy " + (i + 1) + ": " + doanhThuQuy[i] + " VND");
        }
    }

    public void tinhSoLanDatThue() {
        for (DonDatTiec donDatTiec : dsddt) {
            SanhCuoi sanhCuoi = donDatTiec.getSanhCuoi();
            if (sanhCuoi != null) {
                sanhCuoi.getSoLanDatThue();
            }
        }
    }

    public void sapXepTheoTanSoThue() {

        tinhSoLanDatThue(); // Tính số lần đặt thuê trước khi sắp xếp
        Collections.sort(qlsc.getSc(), new Comparator<SanhCuoi>() {
            @Override
            public int compare(SanhCuoi s1, SanhCuoi s2) {
                // So sánh theo số lần được đặt thuê giảm dần
                return Integer.compare(s2.getSoLanDatThue(), s1.getSoLanDatThue());
            }
        });
        System.out.println("Danh sach sanh cuoi theo tan so thue:");
        for (SanhCuoi sanhCuoi : qlsc.getSc()) {
            System.out.println("Ma sanh: " + sanhCuoi.getMaSanh());
            System.out.println("Ten sanh: " + sanhCuoi.getTenSanh());
            System.out.println("So lan duoc thue: " + sanhCuoi.getSoLanDatThue());
            System.out.println("=======================");
        }
    }

    public void traCuuSanhDaThueTheoNam(int nam) {
        System.out.println("Sanh da duoc thue trong nam " + nam + ":");
        Set<String> daInRa = new HashSet<>();

        for (DonDatTiec donDatTiec : dsddt) {
            if (donDatTiec.getNam() == nam) {
                SanhCuoi sanhCuoi = donDatTiec.getSanhCuoi();
                if (sanhCuoi != null && !daInRa.contains(sanhCuoi.getMaSanh())) {
//                    int namCanTim = 2023; // Thay đổi năm cần tra cứu
                    int soLanDatThueTheoNam = sanhCuoi.getSoLanDatThueTheoNam(nam);

                    // In thông tin sảnh đã được thuê
                    System.out.println("Ma sanh: " + sanhCuoi.getMaSanh());
                    System.out.println("Ten sanh: " + sanhCuoi.getTenSanh());
                    System.out.println("So lan dat thue nam " + nam + ": " + soLanDatThueTheoNam);
                    //                    System.out.println("So lan duoc thue:" + sanhCuoi.getSoLanDatThue());
                    System.out.println("=======================");
                    daInRa.add(sanhCuoi.getMaSanh());

                }
            }
        }

    }

    public DonDatTiec timDonDatTiecTheoTen(String tenBuaTiec) {
        for (DonDatTiec donDatTiec : dsddt) {
            if (donDatTiec.getTenBuaTiec().equalsIgnoreCase(tenBuaTiec)) {
                return donDatTiec;
            }
        }

        return null; // Trả về null nếu không tìm thấy
    }

    public void themDDT() {
        DonDatTiec a = new DonDatTiec();
        a.nhap1DDT();
        this.dsddt.add(a);
    }

    public void themDDT(DonDatTiec... a) {
        this.dsddt.addAll(Arrays.asList(a));
    }

    public void hienThi() {
        this.dsddt.forEach(h -> System.out.println(h));

    }

}
