/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ym.btl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author ADMIN
 */
public class QuanLyDichVu {
    private List<DichVu> dv= new ArrayList<>();
    
   public void themDichVu(DichVu...a){
        this.dv.addAll(Arrays.asList(a));
   }
   public void themKaraoke(double giaDV,int thoiGianThue) {
    this.dv.add(new Karaoke(giaDV, thoiGianThue));
  }
    public void themThueCaSi(double giaDV, String tenCaSi, int soLuongBH){
       this.dv.add(new ThueCaSi(giaDV, tenCaSi, soLuongBH));
    } 
    public void themTrangTri(double giaDV){
       this.dv.add(new TrangTri(giaDV));
    } 
   public void xoaDichVu(String kw){
       this.dv.removeIf(h -> h.maDV.equalsIgnoreCase(kw));
   }
  
   public void capNhatKaraoke(String maDV,double giaDV,int thoiGianThue){
       for (DichVu dichVu : dv) {
            if (dichVu.getMaDV().equalsIgnoreCase(maDV)) {
                dichVu.setGiaDV(giaDV);
                dichVu.setThoiGianThue(thoiGianThue);
                System.out.println("Thong tin dich vu da duoc cap nhat thanh cong!");
                return; //kết thúc vòng lặp khi tìm thấy
            }
        }
        System.out.println("Khong tim thay dich vu voi ma" + maDV);
   }
   public void capNhatThueCaSi(String maDV,double giaDV, String tenCaSi, int soLuongBH){
       for (DichVu dichVu : dv) {
            if (dichVu.getMaDV().equalsIgnoreCase(maDV)) {
                dichVu.setGiaDV(giaDV);
                dichVu.setTenCaSi(tenCaSi);
                dichVu.setSoLuongBH(soLuongBH);
                System.out.println("Thong tin dich vu da duoc cap nhat thanh cong!");
                return; //kết thúc vòng lặp khi tìm thấy
            }
        }
        System.out.println("Khong tim thay dich vu voi ma" + maDV);
   }

    public void capNhatTrangTri(String maDV,double giaDV){
       for (DichVu dichVu : dv) {
            if (dichVu.getMaDV().equalsIgnoreCase(maDV)) {
                dichVu.setGiaDV(giaDV);
                System.out.println("Thong tin dich vu da duoc cap nhat thanh cong!");
                return; //kết thúc vòng lặp khi tìm thấy
            }
        }
        System.out.println("Khong tim thay dich vu voi ma" + maDV);
   }
   public List<DichVu> traCuuDichVuTheoTen(String tenDichVu) {
        List<DichVu> ketQua = new ArrayList<>();

        for (DichVu dichVu : dv) {
            if (dichVu.getTenDV().equalsIgnoreCase(tenDichVu)) {
                ketQua.add(dichVu);
            }
        }

        return ketQua;
    }
   
   public DichVu timKiemTheoMaDV(String maDV) {
        for (DichVu dichVu : dv) {
            if (dichVu.getMaDV().equalsIgnoreCase(maDV)) {
                return dichVu;
            }
        }
        return null; // Trả về null nếu không tìm thấy
    }

  
   
    public void hienThi(){
       for( DichVu a:dv){
        a.hienThi();
    }
    }
            
}

