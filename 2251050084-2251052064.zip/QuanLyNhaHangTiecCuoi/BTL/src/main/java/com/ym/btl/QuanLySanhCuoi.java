/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ym.btl;





import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author ADMIN
 */
public class QuanLySanhCuoi {

    private List<SanhCuoi> sc = new ArrayList<>();
    

    

    public SanhCuoi timKiemTheoMaSC(String maSC) {
        for (SanhCuoi sanhCuoi : sc) {
            if (sanhCuoi.getMaSanh().equalsIgnoreCase(maSC)) {
                return sanhCuoi;
            }
        }
        return null; // Trả về null nếu không tìm thấy
    }
    public void themSC(SanhCuoi... s) {
        this.sc.addAll(Arrays.asList(s));
    }

    public void themSC() {
        SanhCuoi s = new SanhCuoi();
        s.nhap1SC();
        this.sc.add(s);
    }

    public void xoaSC(String kw) {
        this.sc.removeIf(h -> h.getMaSanh().equalsIgnoreCase(kw));
    }

    public void capNhatSC(String maSanh, String tenMoi, String viTriMoi, int sucChuaMoi) {
        for (SanhCuoi sanhCuoi : sc) {
            if (sanhCuoi.getMaSanh().equalsIgnoreCase(maSanh)) {
                sanhCuoi.setTenSanh(tenMoi);
                sanhCuoi.setViTri(viTriMoi);
                sanhCuoi.setSucChua(sucChuaMoi);
                System.out.println("Thong tin sanh cuoi da duoc cap nhat thanh cong!");
                return; //kết thúc vòng lặp khi tìm thấy
            }
        }
        System.out.println("Khong tim thay sanh cuoi voi ma" + maSanh);
    }

    public void timKiemTheoTenSanh(String tenSanh) {
       
        
        for (SanhCuoi sanh : sc) {
            if (sanh.getTenSanh().equalsIgnoreCase(tenSanh)) {
                System.out.println("Danh sach sanh cuoi co thong tin can tim theo TenSanh:");
                System.out.println(sanh);
            }
        }
    }

    public void timKiemTheoViTri(String viTri) {
        System.out.println("Danh sach sanh cuoi co thong tin can tim theo ViTri:");

        for (SanhCuoi sanh : sc) {
            if (sanh.getViTri().equalsIgnoreCase(viTri)) {
                System.out.println(sanh);
            }
        }
    }
    public void timKiemTheoSucChua(int sucChua) {
        System.out.println("Danh sach sanh cuoi co thong tin can tim theo SucChua:");

        for (SanhCuoi sanh : sc) {
            if (sanh.getSucChua() == sucChua) {
                System.out.println(sanh);
            }
        }
    }

    public void hienThi2() {
        this.sc.forEach(h -> System.out.println(h));
    }

    /**
     * @return the sc
     */
    public List<SanhCuoi> getSc() {
        return sc;
    }

    /**
     * @param sc the sc to set
     */
    public void setSc(List<SanhCuoi> sc) {
        this.sc = sc;
    }

}