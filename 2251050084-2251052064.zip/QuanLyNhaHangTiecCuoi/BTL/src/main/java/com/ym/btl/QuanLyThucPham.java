/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ym.btl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author ADMIN
 */
public class QuanLyThucPham {
   private List<ThucPham> tps=new ArrayList<>();
//   public void themMonAn(){
//       ThucAn t=new ThucAn();
//       t.nhap1ThucAn();
//       this.tps.add(t);
//   }
   public void themVaoDSTP(ThucPham...tp) {
    this.tps.addAll(Arrays.asList(tp));
  }
//   void themMonAn(ThucPham...a){
//        this.tps.addAll(Arrays.asList(a));
//   }
//   void themThucUong(ThucPham...a){
//        this.tps.addAll(Arrays.asList(a));
//   }
   public void themMonAn(String tenMon, double giaMon,boolean isAnChay) {      
    this.tps.add(new ThucAn(tenMon, giaMon, isAnChay));
  }
    public void themThucUong(String tenMon,double giaMon,String hangSX){
       this.tps.add(new ThucUong(tenMon, giaMon, hangSX));
    }
     public void xoaThucUong(String kw){
       this.tps.removeIf(h -> h.getMaMon().equalsIgnoreCase(kw));
   }
   public void xoaThucAn(String kw){
       this.tps.removeIf(h -> h.getMaMon().equalsIgnoreCase(kw));
   }
       public void capNhatTA(String maMon, String tenMon,double giaMon,boolean isAnChay){
       for (ThucPham thucPham: tps) {
            if (thucPham.getMaMon().equalsIgnoreCase(maMon)) {
                thucPham.setTenMon(tenMon);
                thucPham.setGiaMon(giaMon);
                thucPham.setIsAnChay(isAnChay);
                System.out.println("Thong tin mon an da duoc cap nhat thanh cong!");
                return; //kết thúc vòng lặp khi tìm thấy
            }
        }
        System.out.println("Khong tim thay mon an voi ma" + maMon);
   }
   public void capNhatTU(String maMon, String tenMon,double giaMon,String hangSX){
       for (ThucPham thucPham : tps) {
            if (thucPham.getMaMon().equalsIgnoreCase(maMon)) {
                thucPham.setTenMon(tenMon);
                thucPham.setGiaMon(giaMon);
                thucPham.setHangSX(hangSX);
                System.out.println("Thong tin thuc uong da duoc cap nhat thanh cong!");
                return; //kết thúc vòng lặp khi tìm thấy
            }
        }
        System.out.println("Khong tim thay thuc uong voi ma" + maMon);
   }
   public void timThucAn(String tenThucAn) {
       boolean fl = true;
        for (ThucPham thucPham : tps) {
            if (thucPham instanceof ThucAn thucAn) {
                if (thucAn.getTenMon().equalsIgnoreCase(tenThucAn)) {
                    fl=false;
                    thucAn.hienThi();                    
                }
            }
        }
         if(fl==true)
            System.out.println("Khong tim thay thuc an co ten: "+tenThucAn);
    }
   public void timThucUong(String tenThucUong) {
       boolean fl = true;
        for (ThucPham thucPham : tps) {
            if (thucPham instanceof ThucUong thucUong) {
                if (thucUong.getTenMon().equalsIgnoreCase(tenThucUong)) {
                    fl=false;
                    thucUong.hienThi();
                }
            }
        }
        if(fl==true)
            System.out.println("Khong tim thay thuc uong co ten: "+tenThucUong);
    }
   public void hienThi(){
       for (ThucPham thucPham : tps) {
            thucPham.hienThi();
        }
       }
   
   public ThucPham timKiemThucPhamTheoMa(String maThucPham) {
        for (ThucPham thucPham : tps) {
            if (thucPham.getMaMon().equalsIgnoreCase(maThucPham)) {
                return thucPham;
            }
        }
        return null; // Trả về null nếu không tìm thấy
    }
   public void inDanhSachThucAn() {
       
        for (ThucPham thucPham : tps) {
            if (thucPham instanceof ThucAn) {
                System.out.println(thucPham.getMaMon() + ": " + thucPham.getTenMon()+": "+thucPham.getGiaMon());
            }
        }
    }
   public void inDanhSachThucUong() {
       
        for (ThucPham thucPham : tps) {
            if (thucPham instanceof ThucUong) {
                System.out.println(thucPham.getMaMon() + ": " + thucPham.getTenMon()+": "+thucPham.getGiaMon());
            }
        }
    }
   public List<ThucPham> getDsThucPham() {
        return tps;
    }
      
}

