/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ym.btl;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author ADMIN
 */
public class SanhCuoi {
    private static int dem;
    protected String maSanh;
    private String tenSanh;
    private String viTri;
    private int sucChua;
    private int soLanDatThue;
    private Map<Integer, Integer> soLanDatThueTheoNam = new HashMap<>();

    public SanhCuoi() {
    }
    

    public SanhCuoi(String tenSanh, String viTri, int sucChua) {
        this.tenSanh = tenSanh;
        this.viTri = viTri;
        this.sucChua = sucChua;
        this.soLanDatThue=0;
//        this.giaThueSanh = giaThueSanh;
    }

    @Override
    public String toString() {
        return "Ma Sanh: "+this.maSanh+"\nTen Sanh: "+this.tenSanh+"\nVi tri: Tang "+this.viTri+"\nSuc chua:"
                +this.sucChua;
    }
    
    
   public void nhap1SC(){
       System.out.println("Ten Sanh = ");
       this.tenSanh = CauHinh.SC.nextLine();
       System.out.println("Vi Tri = ");
       this.viTri = CauHinh.SC.nextLine();
       System.out.println("Suc Chua = ");
       this.sucChua = Integer.parseInt(CauHinh.SC.nextLine());

    
    
    
    }
    {
        maSanh = String.format("S%04d", ++dem);
    }

    /**
     * @return the maSanh
     */
    public String getMaSanh() {
        return maSanh;
    }

    /**
     * @param maSanh the maSanh to set
     */
    public void setMaSanh(String maSanh) {
        this.maSanh = maSanh;
    }

    /**
     * @return the tenSanh
     */
    public String getTenSanh() {
        return tenSanh;
    }

    /**
     * @param tenSanh the tenSanh to set
     */
    public void setTenSanh(String tenSanh) {
        this.tenSanh = tenSanh;
    }

    /**
     * @return the viTri
     */
    public String getViTri() {
        return viTri;
    }

    /**
     * @param viTri the viTri to set
     */
    public void setViTri(String viTri) {
        this.viTri = viTri;
    }

    /**
     * @return the sucChua
     */
    public int getSucChua() {
        return this.sucChua;
    }

    /**
     * @param sucChua the sucChua to set
     */
    public void setSucChua(int sucChua) {
        this.sucChua = sucChua;
    }

    /**
     * @return the soLanDatThue
     */
    public int getSoLanDatThue() {
        return soLanDatThue;
    }

    /**
     * @param soLanDatThue the soLanDatThue to set
     */
    public void setSoLanDatThue(int soLanDatThue) {
        this.soLanDatThue = soLanDatThue;
    }
   

    // Phương thức để tăng số lần được đặt thuê
    public void datTiec() {
        this.soLanDatThue++;
    }

    /**
     * @return the soLanDatThueTheoNam
     */
    public Map<Integer, Integer> getSoLanDatThueTheoNam() {
        return soLanDatThueTheoNam;
    }

    /**
     * @param soLanDatThueTheoNam the soLanDatThueTheoNam to set
     */
    public void setSoLanDatThueTheoNam(Map<Integer, Integer> soLanDatThueTheoNam) {
        this.soLanDatThueTheoNam = soLanDatThueTheoNam;
    }



   

    // Phương thức để tăng số lần được đặt thuê

    
    public void tangSoLanDatThueTheoNam(int nam) {
        soLanDatThueTheoNam.put(nam, soLanDatThueTheoNam.getOrDefault(nam, 0) + 1);
    }
    public int getSoLanDatThueTheoNam(int nam) {
        return soLanDatThueTheoNam.getOrDefault(nam, 0);
    }



    
    
    
    

}


