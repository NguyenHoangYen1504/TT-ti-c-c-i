/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ym.btl;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * 1
 *
 * @author Admin
 */
public class Tester {

    public static void main(String[] args) {

        SanhCuoi s1 = new SanhCuoi("lama", "1", 30);
        SanhCuoi s2 = new SanhCuoi("hha", "2", 50);
        SanhCuoi s3 = new SanhCuoi("sky", "3", 50);
        QuanLySanhCuoi ql = new QuanLySanhCuoi();
        ql.themSC(s1, s2, s3);

        DichVu a = new Karaoke(500, 3);
        DichVu b = new Karaoke(650, 3);
        DichVu c = new Karaoke(300, 3);
        DichVu d = new ThueCaSi(500, "Hiethuhai", 10);
        DichVu e = new ThueCaSi(300, "Issac", 7);
        DichVu f = new ThueCaSi(400, "Anh Tu", 50);
        DichVu g = new TrangTri(400);
        QuanLyDichVu qldv = new QuanLyDichVu();
        qldv.themDichVu(a, b, c, d, e, f, g);

        ThucPham h = new ThucAn("Tom", 350, false);
        ThucPham i = new ThucAn("Ca", 200, false);
        ThucPham j = new ThucAn("Heo", 200, false);
        ThucPham k = new ThucAn("Ga", 200, false);
        ThucPham l = new ThucAn("Bo", 400, false);
        ThucPham m = new ThucUong("Pepsi", 10, "numberone");
        ThucPham n = new ThucUong("Sting", 10, "numberone");
        QuanLyThucPham qltp = new QuanLyThucPham();
        qltp.themVaoDSTP(h, i, j, k, l, m, n);

        Menu menu = new Menu();
        Menu menu2 = new Menu();
        Menu menu3 = new Menu();
        QuanLyDDT qlddt = new QuanLyDDT(ql);
        menu.themVaoMenu(h, i, m);
        menu2.themVaoMenu(h, i, j, n);
        menu3.themVaoMenu(h, i, k, m, n);
        DatDichVu dv1 = new DatDichVu();
        DatDichVu dv2 = new DatDichVu();
        DatDichVu dv3 = new DatDichVu();
        dv1.themDichVu(a, d);
        dv2.themDichVu(b, g);
        dv3.themDichVu(g);

        DonDatTiec d1 = new DonDatTiec("Sinh Nhat", "S0003", 2, 2, 2021, GiaThueSanh.TRUA_THUONG, menu, dv3, ql);
        DonDatTiec d2 = new DonDatTiec("Tiec Cuoi", "S0002", 7, 6, 2022, GiaThueSanh.SANG_T7CN, menu2, dv2, ql);
        DonDatTiec d3 = new DonDatTiec("Tiec nha ", "S0003", 30, 3, 2023, GiaThueSanh.TRUA_T7CN, menu3, dv2, ql);
        DonDatTiec d4 = new DonDatTiec("Tiec san ", "S0002", 30, 12, 2023, GiaThueSanh.SANG_T7CN, menu3, dv2, ql);
        DonDatTiec d5 = new DonDatTiec("Tiec ngu ", "S0001", 30, 3, 2023, GiaThueSanh.TOI_T7CN, menu3, dv2, ql);
        DonDatTiec d6 = new DonDatTiec("Tiec hay", "S0003", 30, 12, 2023, GiaThueSanh.SANG_THUONG, menu3, dv2, ql);
        DonDatTiec d7 = new DonDatTiec("Tiec hh ", "S0003", 30, 12, 2023, GiaThueSanh.CHIEU_THUONG, menu3, dv2, ql);
        DonDatTiec d8 = new DonDatTiec("Tiec ha", "S0001", 30, 5, 2023, GiaThueSanh.SANG_T7CN, menu3, dv2, ql);
        qlddt.themDDT(d1, d2, d3, d4, d5, d6, d7, d8);

        Scanner scanner = new Scanner(System.in);

        int choice = 0;
        do {
            System.out.println("=== MENU ===");
            System.out.println("\n1. Quan ly thong tin sanh cuoi");
            System.out.println("\n2. Quan ly thong tin dich vu");
            System.out.println("\n3. Quan ly thong tin thuc an,thuc uong ");
            System.out.println("\n4. Thong tin cho thue sanh ");
            System.out.println("\n5. Sap xep sanh da thue ");
            System.out.println("\n6. Tra cuu sanh da thue theo nam ");
            System.out.println("\n7. Xuat hoa don ");
            System.out.println("\n8. Bao cao doanh thu theo thang ");
            System.out.println("\n9. Bao cao doanh thu theo quy ");
            System.out.println("\n0. Thoat");

            System.out.print("Nhap lua chon cua ban ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1 -> {
                    int sanhChoice = 0;
                    do {
                        System.out.println("=== QUAN LY SANH CUOI ===");
                        System.out.println("1. Hien thi danh sach sanh cuoi");
                        System.out.println("2. Them sanh cuoi");
                        System.out.println("3. Xoa sanh cuoi");
                        System.out.println("4. Cap nhat thong tin sanh cuoi");
                        System.out.println("5. Tra cuu sanh cuoi theo ten");
                        System.out.println("6. Tra cuu sanh cuoi theo vi tri");
                        System.out.println("7. Tra cuu sanh cuoi theo suc chua");
                        System.out.println("0. Quay lai");

                        System.out.print("Nhap lua chon cua ban: ");
                        sanhChoice = scanner.nextInt();

                        switch (sanhChoice) {
                            case 1:
                                ql.hienThi2();
                                break;
                            case 2:
                                System.out.println("Nhap thong tin sanh cuoi moi:");
                                // Thêm sảnh cưới
                                ql.themSC();
                                break;
                            case 3:
                                ql.hienThi2();
                                System.out.print("Nhap ma sanh can xoa: ");
                                String maSanhCanXoa = scanner.next();
                                ql.xoaSC(maSanhCanXoa);
                                break;
                            case 4:
                                System.out.print("Nhap ma sanh cuoi can cap nhat: ");
                                String maSanhCanCapNhat = scanner.next();
                                System.out.print("NNhap ten sanh moi: ");
                                String tenMoi = scanner.next();
                                System.out.print("Nhap vi tri moi: ");
                                String viTriMoi = scanner.next();
                                System.out.print("Nhap suc chua moi: ");
                                int sucChuaMoi = scanner.nextInt();
//                                System.out.println("Nhập giá thuê sảnh mới: ");
//                                System.out.println("1. TOI_T7CN");
//                                System.out.println("2. SANG_THUONG");
//                                System.out.println("3. CHIEU_THUONG");
//                                GiaThueSanh giaThue = GiaThueSanh.values()[scanner.nextInt() - 1];
                                ql.capNhatSC(maSanhCanCapNhat, tenMoi, viTriMoi, sucChuaMoi);
                                break;
                            case 5:
                                System.out.print("Nhap ten sanh can tim: ");
                                scanner.nextLine();
                                String tenSanh = scanner.nextLine();
                                ql.timKiemTheoTenSanh(tenSanh);
                                break;
                            case 6:
                                System.out.print("Nhap vi tri sanh can tim: ");
                                scanner.nextLine();
                                String viTri = scanner.nextLine();
                                ql.timKiemTheoViTri(viTri);
                                break;
                            case 7:
                                System.out.print("Nhap suc chua sanh can tim: ");
                                scanner.nextLine();
                                int suchua = scanner.nextInt();
                                ql.timKiemTheoSucChua(suchua);
                                break;
                            case 0:
                                System.out.println("Quay lai menu chinh.");
                                break;
                            default:
                                System.out.println("Lua chon khong hop le vui long thu lai.");
                                break;
                        }
                    } while (sanhChoice != 0);
                }
                case 2 -> {
                    int dvChoice = 0;
                    do {
                        System.out.println("=== QUAN LY DICH VU ===");
                        System.out.println("1. Hien thi danh sach dich vu");
                        System.out.println("2. Them dich vu karaoke");
                        System.out.println("3. Them dich vu thue ca si");
                        System.out.println("4. Them dich vu thue trang tri");
                        System.out.println("5. Xoa dich vu");
                        System.out.println("6. Cap nhat thong tin dich vu karaoke");
                        System.out.println("7. Cap nhat thong tin dich vu thue ca si");
                        System.out.println("8. Cap nhat thong tin dich vu thue trang tri");
                        System.out.println("9. Tra cuu dich vu theo ten");
                        System.out.println("0. Quay lai");

                        System.out.print("Nhap lua chon cua ban: ");
                        dvChoice = scanner.nextInt();

                        switch (dvChoice) {
                            case 1:
                                qldv.hienThi();
                                break;
                            case 2:
                                System.out.println("==Them dich vu karaoke  moi==");
                                // Thêm dv karaoke
                                System.out.println("Them gia  dich vu karaoke  moi:");
                                Double giaDV = scanner.nextDouble();
                                System.out.println("Them thoi gian thue dich vu karaoke  moi(tieng):");
                                int thoiGianThue = scanner.nextInt();
                                qldv.themKaraoke(giaDV, thoiGianThue);
                                break;
                            case 3:
                                System.out.println("==Them dich vu thue ca si moi==");
                                System.out.println("Them gia dich vu thue ca si moi: ");
                                Double giaDVc = scanner.nextDouble();
                                System.out.println("Them ten ca si moi: ");
                                scanner.nextLine();
                                String tenCaSiM = scanner.nextLine();
                                System.out.println("Them so luong bai hat moi: ");
                                int soLuongbaihat = scanner.nextInt();

                                qldv.themThueCaSi(giaDVc, tenCaSiM, soLuongbaihat);
                                break;
                            case 4:
                                System.out.println("==Them dich vu trang tri moi==");
                                System.out.println("Them gia dich vu trang tri moi: ");
                                Double giaDVt = scanner.nextDouble();
                                qldv.themTrangTri(giaDVt);
                                break;
                            case 5:
                                qldv.hienThi();
                                System.out.println("Nhap ma dichvu can xoa: ");
                                String maDichVuCanXoa = scanner.next();
                                qldv.xoaDichVu(maDichVuCanXoa);
                                break;
                            case 6:
                                System.out.println("Nhap ma dich vu karaoke can cap nhat: ");
                                String maKaraokeCanCapNhat = scanner.next();
                                System.out.println("Nhap gia moi: ");
                                Double giaMoi = scanner.nextDouble();
                                System.out.println("Nhap thoi gian thue moi: ");
                                int thoiGianMoi = scanner.nextInt();
                                qldv.capNhatKaraoke(maKaraokeCanCapNhat, giaMoi, thoiGianMoi);
                                break;
                            case 7:
                                System.out.println("Nhap ma dich vu thue ca si can cap nhat: ");
                                String maThueCaSiCapNhat = scanner.next();
                                scanner.nextLine();
                                System.out.println("Nhap gia moi: ");
                                Double giaMoic = scanner.nextDouble();
                                System.out.println("Nhap ten ca si  moi: ");
                                scanner.nextLine();
                                String tenCaSiMoi = scanner.nextLine();
                                System.out.println("Nhap so luong bai hat moi: ");
                                int soLuongBaiHatMoi = scanner.nextInt();
                                qldv.capNhatThueCaSi(maThueCaSiCapNhat, giaMoic, tenCaSiMoi, soLuongBaiHatMoi);
                                break;
                            case 8:
                                System.out.println("Nhap ma dich vu trang tri can cap nhat: ");
                                String maTrangTriCapNhat = scanner.next();
                                System.out.println("Nhap gia moi: ");
                                Double giaMoit = scanner.nextDouble();
                                qldv.capNhatTrangTri(maTrangTriCapNhat, giaMoit);
                                break;
                            case 9:
                                List<DichVu> kq = new ArrayList<>();
                                System.out.println("Nhap ten dich vu can tim: ");
                                scanner.nextLine();
                                String tenDV = scanner.nextLine();
                                kq = qldv.traCuuDichVuTheoTen(tenDV);
                                for (DichVu x : kq) {
                                    x.hienThi();
                                }
                                break;

                            case 0:
                                System.out.println("Quay lai menu chinh.");
                                break;
                            default:
                                System.out.println("Lua chon khong hop le. Vui long thu lai");
                                break;
                        }
                    } while (dvChoice != 0);

                }
                case 3 -> {
                    int tpChoice = 0;
                    do {
                        System.out.println("\n=== QUAN LY THUC PHAM ===");
                        System.out.println("1. Hien thi danh sach thuc pham");
                        System.out.println("2. Them mon an");
                        System.out.println("3. Them thuc uong");
                        System.out.println("4. Cap nhat thuc an");
                        System.out.println("5. Cap nhat thuc uong");
                        System.out.println("6. Xoa thuc an");
                        System.out.println("7. Xoa thuc uong");
                        System.out.println("8. Tra cuu thuc an theo ten");
                        System.out.println("9. Tra cuu thuc uong theo ten");
                        System.out.println("0. Quay lai");

                        System.out.print("Nhap lua chon cua ban: ");
                        tpChoice = scanner.nextInt();

                        switch (tpChoice) {
                            case 1:
                                qltp.hienThi();
                                break;
                            case 2:
                                System.out.println("==Them thuc an==");
                                System.out.println("Them ten mon  moi:");
                                scanner.nextLine();
                                String tenMon = scanner.nextLine();
                                System.out.println("Them gia mon moi:");
                                Double giaMon = scanner.nextDouble();
                                System.out.println("Co phai mon chay khong (true/false):");
                                boolean isAnChay = scanner.nextBoolean();
                                qltp.themMonAn(tenMon, giaMon, isAnChay);
                                break;
                            case 3:
                                System.out.println("==Them thuc uong==");
                                scanner.nextLine();
                                System.out.println("Them ten thuc uong  moi:");
                                String tenThucUong = scanner.nextLine();
                                System.out.println("Them gia thuc uong moi:");
                                Double giaThucUong = scanner.nextDouble();
                                System.out.println("Nhap hang san xuat :");
                                scanner.nextLine();
                                String hangSX = scanner.nextLine();
                                qltp.themThucUong(tenThucUong, giaThucUong, hangSX);
                                break;
                            case 4:
                                System.out.println("Nhap ma thuc an  can cap nhat: ");
                                scanner.nextLine();
                                String maMonM = scanner.nextLine();
                                System.out.println("Nhap ten mon an  moi: ");
                                String tenMonM = scanner.nextLine();
                                System.out.println("Nhap gia moi: ");
                                Double giaMoiM = scanner.nextDouble();
                                System.out.println("Co phai mon chay khong (true/false):");
                                boolean isAnChayM = scanner.nextBoolean();
                                qltp.capNhatTA(maMonM, tenMonM, giaMoiM, isAnChayM);
                                break;
                            case 5:
                                System.out.println("Nhap ma thuc uong  can cap nhat: ");
                                scanner.nextLine();
                                String maMonTU = scanner.nextLine();
                                System.out.println("Nhap ten thuc uong  moi: ");
                                String tenMonTU = scanner.nextLine();
                                System.out.println("Nhap gia moi: ");
                                Double giaMoiTU = scanner.nextDouble();
                                System.out.println("Nhap hang san xuat :");
                                scanner.nextLine();
                                String hangSXTU = scanner.nextLine();
                                qltp.capNhatTU(maMonTU, tenMonTU, giaMoiTU, hangSXTU);
                                break;
                            case 6:
                                qltp.hienThi();
                                System.out.println("\nNhap ma thuc an can xoa: ");
                                scanner.nextLine();
                                String maThucAnCanXoa = scanner.nextLine();
                                qltp.xoaThucAn(maThucAnCanXoa);
                                break;
                            case 7:
                                qltp.hienThi();
                                System.out.println("\nNhap ma thuc uong can xoa: ");
                                scanner.nextLine();
                                String maThucUongCanXoa = scanner.nextLine();
                                qltp.xoaThucUong(maThucUongCanXoa);
                                break;
                            case 8:
                                System.out.print("Nhap ten thuc an can tim: ");
                                scanner.nextLine();
                                String tenTA = scanner.nextLine();
                                qltp.timThucAn(tenTA);
                                break;
                            case 9:
                                System.out.print("Nhap ten thuc uong can tim: ");
                                scanner.nextLine();
                                String tenTU = scanner.nextLine();
                                qltp.timThucUong(tenTU);
                                break;

                            case 0:
                                System.out.println("Quay lai menu chinh.");
                                break;
                            default:
                                System.out.println("Lua chon khong hop le. Vui long thu lai");
                                break;
                        }
                    } while (tpChoice != 0);

                }
                case 4 -> {
                    int tChoice = 0;
                    do {
                        System.out.println("\n=== CHO THUE TIEC ===");
                        System.out.println("1.Nhap thong tin de thue tiec");
                        System.out.println("0. Quay lai");

                        System.out.print("Nhap lua chon cua ban: ");
                        tChoice = scanner.nextInt();

                        switch (tChoice) {
                            case 1:
                                System.out.println("\nNhap thong tin don dat tiec:");
                                scanner.nextLine();
                                System.out.print("*Ten buoi tiec: ");
                                String tenBuoiTiec = scanner.nextLine();
                                String maSanh;
                                char chonSanhCuoi;
                                do {
                                    System.out.println("Danh sach sanh cuoi:");
                                    ql.hienThi2();

                                    // Nhập thông tin đơn đặt tiệc
                                    // Chọn sảnh cưới
                                    System.out.print("*Chon ma sanh cuoi: ");
                                    maSanh = scanner.nextLine();
                                    SanhCuoi sanhCuoi = ql.timKiemTheoMaSC(maSanh);

                                    if (sanhCuoi == null) {
                                        System.out.println("Khong tim thay sanh cuoi voi ma " + maSanh);
                                    } else {
                                        break; // Thoát khỏi vòng lặp nếu tìm thấy thông tin sảnh cưới
                                    }
                                } while (true);

                                // Nhập thông tin đơn giá thuê sảnh
                                // Nhập thông tin thời điểm thuê
                                System.out.println("\nChon thoi diem thue sanh (SANG_THUONG, TRUA_THUONG, CHIEU_THUONG,SANG_T7CN,TRUA_T7CN,TOI_T7CN):");
                                String thoiDiemThue = CauHinh.SC.nextLine().toUpperCase();

                                // Nhập thông tin ngày thuê
                                System.out.print("Ngay thue (ngay/thang/nam): ");
                                int ngay = scanner.nextInt();
                                int thang = scanner.nextInt();
                                int nam = scanner.nextInt();

                                // Chọn menu thức ăn
                                System.out.println("->Chon menu thuc an:");
                                Menu men = new Menu();

//                                qltp.inDanhSachThucAn();
                                char chonThucAn;

                                do {
                                    qltp.inDanhSachThucAn();
                                    System.out.print("*Chon ma thuc an: ");
                                    String maThucAn = scanner.next();

                                    // Kiểm tra xem mã thức ăn có tồn tại trong danh sách không
                                    ThucPham thucAn = qltp.timKiemThucPhamTheoMa(maThucAn);

                                    if (thucAn != null) {
                                        men.themVaoMenu(thucAn);
                                        System.out.println("->Da them " + thucAn.getTenMon() + " vao danh sach.");
                                    } else {
                                        System.out.println("Khong tim thay thuc an voi ma " + maThucAn);
                                    }

                                    System.out.print("Ban co muon chon them thuc an khac? (Y/N): ");
                                    chonThucAn = scanner.next().charAt(0);
                                } while (chonThucAn == 'Y' || chonThucAn == 'y');
                                System.out.println("Danh sach thuc an da chon:");
                                men.inDanhSachThucAn();
                                System.out.println("Chon menu thuc uong:");
                                qltp.inDanhSachThucUong();
                                char chonThucUong;
                                do {
                                    System.out.print("*Chon ma thuc uong: ");
                                    String maThucUong = scanner.next();

                                    // Kiểm tra xem mã thức ăn có tồn tại trong danh sách không
                                    ThucPham thucUong = qltp.timKiemThucPhamTheoMa(maThucUong);

                                    if (thucUong != null) {
                                        men.themVaoMenu(thucUong);
                                        System.out.println("->Da them " + thucUong.getTenMon() + " vao danh sach.");
                                    } else {
                                        System.out.println("Khong tim thay thuc an voi ma " + maThucUong);
                                    }

                                    System.out.print("Ban co muon chon them thuc uong khac? (Y/N): ");
                                    chonThucUong = scanner.next().charAt(0);
                                } while (chonThucUong == 'Y' || chonThucUong == 'y');

                                //Hiển thị danh sách thức ăn đã chọn
                                System.out.println("Danh sach thuc uong da chon:");
                                men.inDanhSachThucUong();

                                // Nhập thông tin đơn giá menu
                                // Chọn dịch vụ đính kèm
                                DatDichVu datDichVu = new DatDichVu();
                                char chonDichVu;
                                do {
                                    System.out.println("Chon dich vu dinh kem:");
                                    qldv.hienThi();
                                    System.out.print("*Chon ma dich vu: ");
                                    String maDichVu = scanner.next();
                                    DichVu dichVu = qldv.timKiemTheoMaDV(maDichVu);

                                    if (dichVu != null) {
                                        datDichVu.themDichVu(dichVu);
                                        System.out.println("Dich vu " + maDichVu + " da duoc dat.");
                                    } else {
                                        System.out.println("Khong tim thay dich vu voi ma " + maDichVu);
                                    }
                                    System.out.print("Ban co muon chon them dich vu khac? (Y/N): ");
                                    chonDichVu = scanner.next().charAt(0);
                                } while (chonDichVu == 'Y' || chonDichVu == 'y');
                                System.out.println("Danh sach dich vu da chon:");
                                datDichVu.hienThi();

                                // Nhập thông tin đơn giá dịch vụ
                                // Tạo đối tượng ĐơnDatTiec
                                DonDatTiec donDatTiec = new DonDatTiec(tenBuoiTiec, maSanh, ngay, thang, nam, GiaThueSanh.valueOf(thoiDiemThue), men, datDichVu, ql);

                                // Thêm thức ăn vào đơn đặt tiệc
                                qlddt.themDDT(donDatTiec);
                                break;

                            case 0:
                                System.out.println("Quay lai menu chinh.");
                                break;
                            default:
                                System.out.println("Lua chon khong hop le. Vui long thu lai");
                                break;
                        }
                    } while (tChoice != 0);
                }
                case 5 -> {
                    System.out.println("\nSap xep theo tan so duoc thue");
                    qlddt.sapXepTheoTanSoThue();
                    break;
                }
                case 6 -> {
                    System.out.println("\nNhap vao nam can tra cuu:");
                    int tracuu = scanner.nextInt();
                    qlddt.traCuuSanhDaThueTheoNam(tracuu);
                    break;
                }

                case 7 -> {
                    scanner.nextLine();
                    System.out.println("\nNhap vao ten don dat tiec:");
                    String tBuoiTiec = scanner.nextLine();
                    DonDatTiec ddt = new DonDatTiec();
                    ddt = qlddt.timDonDatTiecTheoTen(tBuoiTiec);

                    if (ddt != null) {
                        // In thông tin đơn đặt tiệc nếu tìm thấy
                        System.out.println("Thong tin don dat tiec:");
                        System.out.println("Ma don: " + ddt.getMaDon());
                        // In các thông tin khác của đơn đặt tiệc

                        // Sau đó, có thể xuất hóa đơn tại đây
                        System.out.println("Xuat hoa don...");
                        HoaDon hd = new HoaDon(ddt);
                        hd.xuatHoaDon();
                    } else {
                        System.out.println("Khong tim thay don dat tiec " + tBuoiTiec);
                    }
                    break;

                }
                case 8 -> {
                    System.out.println("\nNhap vao nam can bao cao:");
                    int nambc = scanner.nextInt();
                    System.out.println("\nBao cao doanh thu theo thang cho nam " + nambc + ":");
                    qlddt.baoCaoDoanhThuThang(nambc);
                    break;
                }
                case 9 -> {
                    System.out.println("\nNhap vao nam can bao cao:");
                    int namb = scanner.nextInt();
                    qlddt.baoCaoDoanhThuQuy(namb);
                    break;
                }

                case 0 -> {
                    System.out.println("Da thoat chuong trinh.");
                    break;
                }

                default -> {
                    System.out.println("Lua chon khong hop le. Vui long chon lai.");
                    break;
                }
            }

        } while (choice != 0);

        scanner.close();
    }
}
