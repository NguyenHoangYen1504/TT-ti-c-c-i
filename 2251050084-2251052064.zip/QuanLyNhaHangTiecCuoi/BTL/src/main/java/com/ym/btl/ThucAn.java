/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ym.btl;

/**
 *
 * @author ADMIN
 */
public class ThucAn extends ThucPham{
    private static int demMonAn=0;
    boolean isAnChay;
    {
      this.setMaMon(String.format("TA%02d", ++demMonAn));
    }


    public ThucAn() {
        super(null, 0);
    }
   
    public ThucAn(  String tenMon, double giaMon,boolean isAnChay) {
        super( tenMon, giaMon);
        this.isAnChay = isAnChay;
    }
//   public String layMaMonAn() {
//        return this.getMaMon();
//    }

    public void xuatMonAn() {
        System.out.println(this.getTenMon() + ": " +this.getGiaMon());
    }

    /**
     *
     */
    @Override
    public void hienThi() {
        System.out.printf("\nMa mon an:%s\nTen mon an: %s\nGia mon an: %.1f\nAn chay:%b",this.getMaMon(),this.getTenMon(),this.getGiaMon(),this.isIsAnChay());
        
    }

    /**
     * @return the isAnChay
     */
    public boolean isIsAnChay() {
        return isAnChay;
    }

    /**
     * @param isAnChay the isAnChay to set
     */
    
     @Override
    public void setIsAnChay(boolean isAnChay) {
        this.isAnChay = isAnChay;
    }
//public void nhap1ThucAn(){
//       System.out.println("Ten Thuc An = ");
//       this.tenMon = CauHinh.SC.nextLine();
//       System.out.println("Gia thuc an = ");
//       this.giaMon= Double.parseDouble(CauHinh.SC.nextLine());
//       System.out.println("An chay = ");
//       this.isAnChay= Boolean.parseBoolean(CauHinh.SC.nextLine());
//}

    /**
     * @return the demMonAn
     */
    public static int getDemMonAn() {
        return demMonAn;
    }

    /**
     * @param aDemMonAn the demMonAn to set
     */
    public static void setDemMonAn(int aDemMonAn) {
        demMonAn = aDemMonAn;
    }
      
    
}
