/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ym.btl;

/**
 *
 * @author ADMIN
 */
public abstract class ThucPham {

    private String maMon;
    private String tenMon;
    private double giaMon;

    public ThucPham( String tenMon, double giaMon) {
        this.tenMon = tenMon;
        this.giaMon = giaMon;
    }
    
    public abstract void hienThi();

    /**
     * @return the maMon
     */
    public String getMaMon() {
        return maMon;
    }

    /**
     * @param maMon the maMon to set
     */
    public void setMaMon(String maMon) {
        this.maMon = maMon;
    }

    /**
     * @return the tenMon
     */
    public String getTenMon() {
        return tenMon;
    }

    /**
     * @param tenMon the tenMon to set
     */
    public void setTenMon(String tenMon) {
        this.tenMon = tenMon;
    }

    /**
     * @return the giaMon
     */
    public double getGiaMon() {
        return giaMon;
    }

    /**
     * @param giaMon the giaMon to set
     */
    public void setGiaMon(double giaMon) {
        this.giaMon = giaMon;
    }
    public void setIsAnChay(boolean isAnChay) {}
    public void setHangSX(String hangSX) {}
}

