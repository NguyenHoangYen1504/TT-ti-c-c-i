/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ym.btl;

/**
 *
 * @author ADMIN
 */
public class ThucUong extends ThucPham{
    private static int demThucUong=0;
    private String hangSX;
    {
    
        this.setMaMon(String.format("TU%02d", ++demThucUong));
    }

    public ThucUong() {
        super(null, 0);
    }
    
    public ThucUong(String tenMon, double giaMon,String hangSX) {
        super(tenMon, giaMon);
        this.hangSX = hangSX;
    }

//    public String layMaThucUong() {
//        return getMaMon();
//    }

    public void xuatThucUong() {
        System.out.println(getTenMon() + ": " + this.getGiaMon());
    }

 
    @Override
    public void hienThi() {
        System.out.printf("\nMa Thuc Uong:%s\nTen thuc uong:%s\nGia thuc uong:%.1f\nHang san xuat:%s",this.getMaMon(),this.getTenMon(),this.getGiaMon(),this.hangSX);
            }
    

    /**
     * @return the hangSX
     */
    public String getHangSX() {
        return hangSX;
    }

    /**
     * @param hangSX the hangSX to set
     */
    @Override
    public void setHangSX(String hangSX) {
        this.hangSX = hangSX;
    }
    
}

