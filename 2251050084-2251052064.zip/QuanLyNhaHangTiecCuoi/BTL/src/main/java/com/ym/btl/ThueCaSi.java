/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ym.btl;
import static com.ym.btl.DichVu.dem;
/**
 *
 * @author ADMIN
 */
public class ThueCaSi extends DichVu {
   private String tenCaSi;
   private int soLuongBH;
    {
        this.maDV = String.format("DV%03d", ++dem);
    }

    public ThueCaSi(  double giaDV, String tenCaSi, int soLuongBH) {
        super("Thue Ca Si", giaDV);
        this.tenCaSi = tenCaSi;
        this.soLuongBH = soLuongBH;
    }

@Override
    public void hienThi(){
        System.out.printf("===\nDich Vu:%s\nMa dich vu:%s\nGia dich vu:%.1f\n Ten Ca Si:%s\n So luong bai hat:%d%n",
                this.getTenDV(),this.getMaDV(),this.getGiaDV(), this.getTenCaSi(),this.soLuongBH);
    }
    
    
    /**
     * @return the soLuongBH
     */
    public int getSoLuongBH() {
        return soLuongBH;
    }

    /**
     * @param soLuongBH the soLuongBH to set
     */
    public int setSoLuongBH(int soLuongBH) {
        return this.soLuongBH = soLuongBH;
    }

    /**
     * @return the tenCaSi
     */
    public String getTenCaSi() {
        return tenCaSi;
    }

    /**
     * @param tenCaSi the tenCaSi to set
     */
    public void setTenCaSi(String tenCaSi) {
        this.tenCaSi = tenCaSi;
    }
   

    
    

}

