/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ym.btl;

/**
 *
 * @author ADMIN
 */
public class TrangTri extends DichVu{

     {
        this.maDV = String.format("DV%03d", ++dem);
    }

    public TrangTri(double giaDV) {
        super("Trang tri", giaDV);
    }

    @Override
    public void hienThi() {
        System.out.printf("===\nDich Vu:%s\nMa dich vu:%s\nGia dich vu:%.1f\n",this.getTenDV(),this.getMaDV(),this.getGiaDV());
    }

  

  
    
}

